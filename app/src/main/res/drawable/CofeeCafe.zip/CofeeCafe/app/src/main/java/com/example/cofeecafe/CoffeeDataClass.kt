package com.example.cofeecafe

class CoffeeDataClass (var Image: Int, var Title: String, var Price: String, val description: String, val sizes: String) {
}
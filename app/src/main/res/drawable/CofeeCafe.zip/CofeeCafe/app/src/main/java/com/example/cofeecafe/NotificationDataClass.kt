package com.example.cofeecafe

data class NotificationDataClass(var notificationImage : Int){

}
